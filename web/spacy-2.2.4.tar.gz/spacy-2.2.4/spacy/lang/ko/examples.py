# coding: utf8
from __future__ import unicode_literals

"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.ko.examples import sentences
>>> docs = nlp.pipe(sentences)
"""

sentences = [
    "애플이 영국의 신생 기업을 10억 달러에 구매를 고려중이다.",
    "자동 운전 자동차의 손해 배상 책임에 자동차 메이커에 일정한 부담을 요구하겠다.",
    "자동 배달 로봇이 보도를 주행하는 것을 샌프란시스코시가 금지를 검토중이라고 합니다.",
    "런던은 영국의 수도이자 가장 큰 도시입니다.",
]
